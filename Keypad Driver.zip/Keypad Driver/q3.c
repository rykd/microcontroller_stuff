#include <stdint.h>
#include <avr/io.h>
#define F_CPU 16000000
#include <util/delay.h>
#include <avr/interrupt.h>


int main(void)
{
	DDRB = 0x01;
	PORTB = 0x02;
	
	while(1){
		
		if(!(PINB & 0x02)){
			PORTB |= 0x01;
		}
		else{
			PORTB &= 0xFE;
		}		
	}
}