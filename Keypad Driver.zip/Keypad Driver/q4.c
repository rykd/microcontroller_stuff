#include <stdint.h>
#include <avr/io.h>
#define F_CPU 16000000
#include <util/delay.h>
#include <avr/interrupt.h>


int flag1 = 0;
int flag2 = 0;

int main(void)
{
	DDRB = (1 << PORTB0);
	//DDRB = (1 << PORTB1);
	PORTB = (1 << PORTB0);
	//PORTB = (1 << PORTB1);
	
	PORTD = (1 << PORTD3);
	PORTD = (1 << PORTD2);
	EIMSK = (1 << INT1);
	EIMSK = (1 << INT0);
	
    while(1){
		if(flag1*flag2 == 0){
			sei();
		}
		else{
			cli();
			_delay_ms(500);
			flag1 = 0;
			flag2 = 0;
		}
	}
}

ISR(INT1_vect){
	PORTB ^= (1 << PORTB0);
	flag1 = 1;
}

ISR(INT0_vect){
	PORTB ^= (1 << PORTB1);
	flag2 = 1;
}

