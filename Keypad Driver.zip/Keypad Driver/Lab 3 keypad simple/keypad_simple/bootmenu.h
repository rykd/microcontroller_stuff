//* bootmenu.h *
#ifndef BOOTMENU_H_
#define BOOTMENU_H_
#include <stdint.h>

uint8_t boottime_menu();

#endif /* BOOTMENU_H_ */