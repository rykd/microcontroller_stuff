//* lib_kpads_test.h *
#ifndef LIB_KPADS_TEST_H_
#define LIB_KPADS_TEST_H_
#include <stdint.h>

int test0_getkey_value(void);
int test1_count_up(void);
int test2_shift(void);
int test8_keypressed_status(void);

#endif /* LIB_KPAD_TEST_H_ */
