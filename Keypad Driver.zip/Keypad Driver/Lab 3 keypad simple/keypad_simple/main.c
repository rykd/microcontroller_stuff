//* simplified keypad test - main.c *
#include <stdint.h>
#include <avr/interrupt.h>
#include "bootmenu.h"
#include "lib_kpads_test.h"
#include "bios_pwmdac.h"
#include "bios_kpads.h"
#include "bios_leds.h"



volatile uint8_t pwm_rate0;

inline void DC_motor_dir(uint8_t mode) {
	// make sure that there is no pwm1 on the 2nd pin!!
	leds_set( (mode & 0b00000110) | (leds_get() & 0b00000001 ) );
}

void callback_FN_called_from_timer1_interrupt() {

}

void setPWMrate(uint8_t level) {
	// DC motor: (assume levels 0 to 10)
	//pwm_rate0 = level;
	// ServoMotor: (assume PWM step of 0.1ms)
	pwm_rate0 = 5 + 2 * level;
}

inline void shutdownPWMrate() {
	pwm_rate0 = 0;
}



int main() {
	
	DDRC = 0x0f;
	PORTC = 0x00;
	
	DDRD  = 0x0F & DDRD;
	PORTD = 0xF0 | (PORTD & 0x0F);
	
	DDRB = 0xff;
	
	//leds_init();
	int dcmoto = 1;
	Timer2_PWM_initialize();
	Timer2_PWM_setDuty(0x3F); // 25% change and observe PortB.7

	while(1) {
		uint8_t key = keypressed();
		if ( key != KEY_NONE && key != KEY_MANY ) {
			
			if ( dcmoto == 0){
			switch (key)
			{
				case KEY_0 :
				Timer2_PWM_setDuty(0x03);
				break;
				case KEY_1 :
				Timer2_PWM_setDuty(0x06);
				break;
				case KEY_2 :
				Timer2_PWM_setDuty(0x09);
				break; 
				case KEY_3 :
				Timer2_PWM_setDuty(0x0C);
				break;
				case KEY_4 :
				Timer2_PWM_setDuty(0x0F);
				break;
				case KEY_5 :
				Timer2_PWM_setDuty(0x12);
				break;
				case KEY_6 :
				Timer2_PWM_setDuty(0x15);
				break;
				case KEY_7 :
				Timer2_PWM_setDuty(0x18);
				break;
				case KEY_8 :
				Timer2_PWM_setDuty(0x1A);
				break;
				case KEY_9 :
				Timer2_PWM_setDuty(0x1D);
				break;
				case KEY_A :
				Timer2_PWM_setDuty(0x20);
				break;
				case KEY_C :
				Timer2_PWM_shutdown();
				break;

				// below DC motor only
				//case KEY_D :
				//DC_motor_dir( 0b00000010 );
				//break;
				//case KEY_C :
				//DC_motor_dir( 0b00000000 );
				//break;
				}
			}
			
			else{
				PORTB = PORTB | 0b00000001;
				switch (key)
				{
					case KEY_0 :
					Timer2_PWM_setDuty(0x00);
					break;
					case KEY_1 :
					Timer2_PWM_setDuty(0x19);
					break;
					case KEY_2 :
					Timer2_PWM_setDuty(0x33);
					break;
					case KEY_3 :
					Timer2_PWM_setDuty(0x4B);
					break;
					case KEY_4 :
					Timer2_PWM_setDuty(0x64);
					break;
					case KEY_5 :
					Timer2_PWM_setDuty(0x7D);
					break;
					case KEY_6 :
					Timer2_PWM_setDuty(0x96);
					break;
					case KEY_7 :
					Timer2_PWM_setDuty(0xAF);
					break;
					case KEY_8 :
					Timer2_PWM_setDuty(0xC8);
					break;
					case KEY_9 :
					Timer2_PWM_setDuty(0xE1);
					break;
					case KEY_A :
					Timer2_PWM_setDuty(0xFF);
					break;
					case KEY_B :
					PORTB = PORTB & 0x00;
					PORTB = PORTB | 0b00000001;
					break;
					case KEY_C :
					PORTB = PORTB & 0x00;
					PORTB = PORTB | 0b00000010;
					break;
			}
			}
		}
	}

	// Technically clearing pin changed interrupt should be enough but...
	//PCINT_PINB_initialize(0b11110000, FN_called_from_pin_changed_intgerrupt );
}


