//* bootmenu.c *
#include "bootmenu.h"
#include <avr/io.h>
#include <avr/interrupt.h>

uint8_t boottime_menu()
{
    // save PORTD configuration to restore it later
    uint8_t save_dir  = DDRD;
    uint8_t save_port = PORTD;

    DDRD  = 0x0F & DDRD;
    PORTD = 0xF0 | (PORTD & 0x0F);
	
	
	PCICR = (1 << PCIE2);
	PCMSK2 = 0b11110000;
    for (volatile uint8_t i=100; i!=0; i--) ;

    uint8_t choice = ( (~PIND)>>4) & 0x0F;

    // restore PORTD original configuration
    DDRD  = save_dir;
    PORTD = save_port;

    return(choice);
}
